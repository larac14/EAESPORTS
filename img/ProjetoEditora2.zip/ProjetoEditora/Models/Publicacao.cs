﻿namespace ProjetoEditora.Models
{
    public class Publicacao
    {
        public int Id { get; set; }

        public Autor Autor { get; set; }
        public int AutorId { get; set; }


        public Livro Livro { get; set; }
        public int Livroid { get; set; }

    }
}
