﻿using System.ComponentModel.DataAnnotations;
using System.Data.SqlTypes;

namespace ProjetoEditora.Models
{
    public class Livro
    {
        [MaxLength(255)]
        [Required]
        public string Nome { get; set; }
        public int NumeroPaginas { get; set; }

        [Key]
        public int ISBN { get; set; }

        public IEnumerable<Publicacao> Publicacao { get; set; }
    }
}
