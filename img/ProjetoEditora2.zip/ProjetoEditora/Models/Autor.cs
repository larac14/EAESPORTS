﻿using System.ComponentModel.DataAnnotations;

namespace ProjetoEditora.Models
{
    public class Autor
    {
        public int Id { get; set; }

        [MaxLength(255)]
        [Required]
        public string Nome { get; set; }
        public string Email { get; set; }

        public IEnumerable<Publicacao> Publicacao { get; set; }
    }
}
