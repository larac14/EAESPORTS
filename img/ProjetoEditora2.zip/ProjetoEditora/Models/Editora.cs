﻿using System.ComponentModel.DataAnnotations;

namespace ProjetoEditora.Models
{
    public class Editora
    {
        public int Id { get; set; }

        [MaxLength(255)]
        [Required]
        public string Nome { get; set; }
        public string Cidade { get; set; }
    }
}
