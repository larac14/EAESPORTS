﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetoEditora.Data;
using ProjetoEditora.Models;
using System;

namespace ProjetoEditora.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AutoresController : ControllerBase
    {
        private readonly EditoraDbContext _context;

        public AutoresController(EditoraDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        public async Task<IEnumerable<Autor>> GetAutor()
        {
            return await _context.Autores.ToListAsync();
        }

        [HttpGet("id")]
        public async Task<Autor> GetAutor(int id)
        {
            return await _context.Autores.FirstOrDefaultAsync(p => p.Id == id);
        }
        

        [HttpPost]
        public async Task<ActionResult<Autor>> PostAutor(Autor autor)
        {
            _context.Autores.Add(autor);
            await _context.SaveChangesAsync();

            return CreatedAtAction
           (
                "GetProduto",
                new { id = autor.Id }, autor
           );


        }

        [HttpDelete("id")]
        public async Task<ActionResult> DeleteAutor(int id)
        {
            Autor autor = await _context.Autores.FindAsync(id);

            if (autor == null)
            {
                return NotFound();
            }
            _context.Autores.Remove(autor);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }
}
