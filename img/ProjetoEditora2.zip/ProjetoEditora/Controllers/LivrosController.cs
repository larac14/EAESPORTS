﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetoEditora.Data;
using ProjetoEditora.Models;
using System;


namespace ProjetoEditora.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LivrosController : ControllerBase
    {
        private readonly EditoraDbContext _context;

        public LivrosController(EditoraDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        public async Task<IEnumerable<Livro>> GetLivro()
        {
            return await _context.Livros.ToListAsync();
        }

        [HttpGet("id")]
        public async Task<Livro> GetLivro(int id)
        {
            return await _context.Livros.FirstOrDefaultAsync(p => p.ISBN == id);
        }

        [HttpPost]
        public async Task<ActionResult<Livro>> PostLivro(Livro livro)
        {
            _context.Livros.Add(livro);
            await _context.SaveChangesAsync();

            return CreatedAtAction
           (
                "GetProduto",
                new { id = livro.ISBN }, livro
           );


        }

        [HttpDelete("id")]
        public async Task<ActionResult> DeleteLivro(int id)
        {
            Livro livro = await _context.Livros.FindAsync(id);

            if (livro == null)
            {
                return NotFound();
            }
            _context.Livros.Remove(livro);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
