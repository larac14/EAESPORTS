﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetoEditora.Data;
using ProjetoEditora.Models;
using System;

namespace ProjetoEditora.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EditorasController : ControllerBase
    {
        private readonly EditoraDbContext _context;
       

        public EditorasController(EditoraDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        public async Task<IEnumerable<Editora>> GetEditora()
        {
            return await _context.Editoras.ToListAsync();
        }

        [HttpGet("id")]
        public async Task<Editora> GetEditora(int id)
        {
            return await _context.Editoras.FirstOrDefaultAsync(p => p.Id == id);
        }


        [HttpPost]
        public async Task<ActionResult<Editora>> PostEditora(Editora editora)
        {
            _context.Editoras.Add(editora);
            await _context.SaveChangesAsync();

            return CreatedAtAction
           (
                "GetProduto",
                new { id = editora.Id }, editora
           );


        }

        [HttpDelete("id")]
        public async Task<ActionResult> DeleteEditora(int id)
        {
            Editora editora = await _context.Editoras.FindAsync(id);

            if (editora == null)
            {
                return NotFound();
            }
            _context.Editoras.Remove(editora);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
