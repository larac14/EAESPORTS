﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjetoEditora.Data;
using ProjetoEditora.Models;
using System;

namespace ProjetoEditora.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PublicacoesController : ControllerBase
    {
        private readonly EditoraDbContext _context;
       

        public PublicacoesController(EditoraDbContext context)
        {
            _context = context;
        }


        [HttpGet]
        public async Task<IEnumerable<Publicacao>> GetPublicacao()
        {
            return await _context.Publicacoes.ToListAsync();
        }

        [HttpGet("id")]
        public async Task<Publicacao> GetPublicacao(int id)
        {
            return await _context.Publicacoes.FirstOrDefaultAsync(p => p.Id == id);
        }


        [HttpPost]
        public async Task<ActionResult<Publicacao>> PostPublicacao(Publicacao publicacao)
        {
            _context.Publicacoes.Add(publicacao);
            await _context.SaveChangesAsync();

            return CreatedAtAction
           (
                "GetProduto",
                new { id = publicacao.Id }, publicacao
           );


        }

        [HttpDelete("id")]
        public async Task<ActionResult> DeletePublicacao(int id)
        {
            Publicacao publicacao = await _context.Publicacoes.FindAsync(id);

            if (publicacao == null)
            {
                return NotFound();
            }
            _context.Publicacoes.Remove(publicacao);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
