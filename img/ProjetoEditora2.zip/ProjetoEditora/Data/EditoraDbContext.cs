﻿using Microsoft.EntityFrameworkCore;
using ProjetoEditora.Models;

namespace ProjetoEditora.Data
{
    public class EditoraDbContext : DbContext
    {
        public EditoraDbContext (DbContextOptions options) : base(options)
        {
        }

        public DbSet<Livro> Livros { get; set; }
        public DbSet<Editora> Editoras { get; set; }
        public DbSet<Autor> Autores { get; set; }
        public DbSet<Publicacao> Publicacoes { get; set; }


    }
}
